-- Contas a pagar (accounts payable) — the other half of a real cashflow picture. Every
-- other financial object in this schema (duplicatas, purchases, credit_lines...) models
-- money coming IN to a cedente; nothing until now models money going OUT. lib/cashflowForecast.ts
-- needs both sides to project a real balance, not just a receivables total.
CREATE TABLE IF NOT EXISTS payables (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cedente_id INTEGER NOT NULL REFERENCES users(id),
  descricao TEXT NOT NULL,
  fornecedor TEXT NOT NULL DEFAULT '',
  categoria TEXT NOT NULL DEFAULT 'outros', -- fornecedores | folha | impostos | aluguel | outros
  valor REAL NOT NULL,
  vencimento TEXT NOT NULL, -- ISO date (YYYY-MM-DD)
  status TEXT NOT NULL DEFAULT 'pendente' CHECK(status IN ('pendente', 'pago', 'cancelado')),
  recorrente INTEGER NOT NULL DEFAULT 0, -- 1 = monthly recurring (rent, payroll...), used to project past the next known due date
  paid_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_payables_cedente ON payables(cedente_id, status);
