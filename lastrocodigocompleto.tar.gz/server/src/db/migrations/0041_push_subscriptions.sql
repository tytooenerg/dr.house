-- Real Web Push subscriptions (lib/webPush.ts) — a browser's push endpoint + keys, one row
-- per device a user opted in from. A user can have several (desktop, phone), so this is
-- keyed by (user_id, endpoint), not a single column on users.
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user ON push_subscriptions(user_id);
