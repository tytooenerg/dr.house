-- Real insurance commission: every time an investor actually contracts insurance on a
-- duplicata (POST /api/market/:id/insure with a new insurer key), this records the exact
-- premium, Lastro's cut, and the seguradora's net repasse — an auditable event log, the
-- same pattern purchases/webhook_deliveries already use, so revenue can be summed exactly
-- instead of recomputed from mutable current state (which insurer selection can change).
CREATE TABLE IF NOT EXISTS insurance_settlements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  duplicata_id TEXT NOT NULL REFERENCES duplicatas(id),
  investor_id INTEGER NOT NULL REFERENCES users(id),
  insurer_key TEXT NOT NULL,
  premio REAL NOT NULL,
  comissao_lastro REAL NOT NULL,
  repasse_seguradora REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_insurance_settlements_duplicata ON insurance_settlements(duplicata_id);
