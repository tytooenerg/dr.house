-- Success fee on cobrança jurídica: when a duplicata escalated through the Jurídico flow
-- (lib/legalCollection.ts) is actually recovered, Lastro charges a real % fee
-- (admin-configurable via platform_settings, default 5%) against whoever currently holds
-- the receivable — the cedente if it was never sold, or the investidor currently holding
-- it (even after a mercado secundário resale) if it was. The recovery itself (the sacado's
-- payment) happens outside the platform — this only records Lastro's own fee for having
-- assisted the escalation, same "real accounting, simulated money movement" scope as the
-- rest of the settlement layer.
CREATE TABLE IF NOT EXISTS legal_collection_fees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  duplicata_id TEXT NOT NULL REFERENCES duplicatas(id),
  recovered_valor REAL NOT NULL,
  fee_pct REAL NOT NULL,
  fee_valor REAL NOT NULL,
  charged_user_id INTEGER REFERENCES users(id),
  charged_role TEXT NOT NULL CHECK(charged_role IN ('cedente', 'investidor')),
  recorded_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_legal_collection_fees_duplicata ON legal_collection_fees(duplicata_id);
