-- Auto-emissão via ERP (lib/autoEmitJob.ts): dedup log so the same ERP conta a receber
-- never gets turned into a second duplicata on a later job run. Unique per (user, fonte,
-- external id) — the external id is whatever the connector's own record identifier is
-- (Omie's codigo_lancamento_omie, SAP's DocEntry, TOTVS's id).
CREATE TABLE IF NOT EXISTS auto_emit_imports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  fonte TEXT NOT NULL CHECK(fonte IN ('omie', 'sap', 'totvs')),
  external_id TEXT NOT NULL,
  duplicata_id TEXT REFERENCES duplicatas(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, fonte, external_id)
);
