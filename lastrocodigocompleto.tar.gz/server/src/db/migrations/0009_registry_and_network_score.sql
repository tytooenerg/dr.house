-- Multi-registradora routing: which of the 4 BACEN-authorized registries (B3, CERC,
-- Núclea, Grafeno) actually handled a given duplicata's registro.
ALTER TABLE duplicatas ADD COLUMN registradora TEXT;

-- Shared risk signal network: partners (via the public API) and Lastro's own real
-- aceite outcomes contribute payment-behavior observations per CNPJ, independent of
-- whether that sacado has ever transacted on Lastro directly — the "fragmentation fix"
-- for credit data that today lives siloed inside each individual platform.
CREATE TABLE IF NOT EXISTS sacado_network_signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cnpj TEXT NOT NULL,
  reporter_user_id INTEGER NOT NULL REFERENCES users(id),
  tipo TEXT NOT NULL CHECK(tipo IN ('pagamento_pontual','atraso','protesto','contestacao')),
  nota TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_network_signals_cnpj ON sacado_network_signals(cnpj);
