import { useEffect, useState } from 'react';
import { api } from '../../../lib/api';
import { Button } from '../../../components/ui/Button';
import { EmptyState } from '../../../components/ui/EmptyState';

interface AdminDispute {
  id: number;
  duplicataId: string;
  sacado: string;
  cedente: string;
  valorFmt: string;
  motivo: string;
  timeline: { autor: string; texto: string; quando: string }[];
}

export function DisputasPanel({ onCount }: { onCount?: (n: number) => void }) {
  const [disputes, setDisputes] = useState<AdminDispute[]>([]);
  const [noteById, setNoteById] = useState<Record<number, string>>({});
  const [aiSummaryById, setAiSummaryById] = useState<Record<number, { recommendation: string; reasoning: string } | null>>({});
  const [loadingAiId, setLoadingAiId] = useState<number | null>(null);

  const loadDisputes = () => api.get<{ disputes: AdminDispute[] }>('/admin/disputes').then((d) => setDisputes(d.disputes));

  useEffect(() => {
    loadDisputes();
  }, []);

  useEffect(() => {
    onCount?.(disputes.length);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disputes.length]);

  const arbitrate = async (id: number, decision: 'cedente' | 'sacado') => {
    const note = noteById[id]?.trim();
    if (!note) return;
    await api.post(`/admin/disputes/${id}/resolve`, { decision, note });
    loadDisputes();
  };

  const generateAiSummary = async (id: number) => {
    setLoadingAiId(id);
    try {
      const res = await api.get<{ summary: { recommendation: string; reasoning: string } | null }>(`/admin/disputes/${id}/ai-summary`);
      setAiSummaryById((prev) => ({ ...prev, [id]: res.summary }));
    } finally {
      setLoadingAiId(null);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {disputes.map((d) => (
        <div key={d.id} className="bg-white border border-border rounded-card p-6">
          <div className="flex justify-between items-start flex-wrap gap-2.5 mb-3">
            <div>
              <div className="font-mono-num font-bold text-[13px] text-textSecondary">{d.duplicataId}</div>
              <div className="font-bold text-[16px] mt-1">
                {d.cedente} vs {d.sacado} — {d.valorFmt}
              </div>
            </div>
          </div>
          <div className="rounded-[10px] px-4 py-3.5 mb-3 bg-amberBg text-sm">{d.motivo}</div>
          <div className="flex flex-col gap-2 mb-3.5">
            {d.timeline.map((t, i) => (
              <div key={i} className="text-[13px]">
                <b>{t.autor}</b> {t.texto} <span className="text-textMuted">— {t.quando}</span>
              </div>
            ))}
          </div>
          {aiSummaryById[d.id] === undefined ? (
            <Button size="sm" variant="secondary" className="mb-3.5" disabled={loadingAiId === d.id} onClick={() => generateAiSummary(d.id)}>
              {loadingAiId === d.id ? 'Analisando…' : 'Gerar análise da IA (sugestão, não decide sozinha)'}
            </Button>
          ) : aiSummaryById[d.id] ? (
            <div className="rounded-[10px] px-4 py-3.5 mb-3.5 bg-chip text-[13px]">
              <div className="font-bold text-blue mb-1">
                IA sugere: {aiSummaryById[d.id]!.recommendation === 'cedente' ? 'favor do cedente' : aiSummaryById[d.id]!.recommendation === 'sacado' ? 'favor do sacado' : 'inconclusivo — precisa de mais evidência'}
              </div>
              <div className="text-textSecondary">{aiSummaryById[d.id]!.reasoning}</div>
            </div>
          ) : (
            <div className="text-[12.5px] text-textSecondary mb-3.5">Análise indisponível (ANTHROPIC_API_KEY não configurada no servidor).</div>
          )}
          <div className="flex items-center gap-2.5 flex-wrap">
            <input
              className="flex-1 min-w-[220px] px-3 py-2 rounded-md border border-inputBorder text-[13px]"
              placeholder="Nota da decisão de arbitragem"
              value={noteById[d.id] ?? ''}
              onChange={(e) => setNoteById((prev) => ({ ...prev, [d.id]: e.target.value }))}
            />
            <Button size="sm" variant="success" onClick={() => arbitrate(d.id, 'cedente')}>
              Decidir a favor do cedente
            </Button>
            <Button size="sm" variant="danger" onClick={() => arbitrate(d.id, 'sacado')}>
              Decidir a favor do sacado
            </Button>
          </div>
        </div>
      ))}
      {disputes.length === 0 && (
        <div className="bg-white border border-border rounded-card">
          <EmptyState title="Nenhuma disputa em aberto" hint="Disputas escaladas pelo cedente aparecem aqui para arbitragem" />
        </div>
      )}
    </div>
  );
}
